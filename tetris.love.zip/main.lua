screen_width = 98
screen_height = 144
scale_factor = 5
minoSize = 8
cooldown = 20
refresh = 60
speed = refresh
love.graphics.setDefaultFilter('nearest', 'nearest')
math.randomseed(os.time())

grid = {}

minoSprites = {}
minoFactory = {}

tetrominoFactory = {}
tetrominoFactory.templates = {}
tetrominoTypes = {'square', 'j', 'l', 's', 't', 'z', 'long'}

function createMino(sprite, x, y, rotate)
	rotate = rotate or 0  -- optional

	local mino = {}
	mino.x = x
	mino.y = y
	mino.rotate = (rotate / 180) * math.pi
	mino.sprite = sprite

	return mino
end

function createRandomTetromino()
	return createTetromino(tetrominoTypes[math.random(#tetrominoTypes)])
end

function createTetromino(type)
	local tetromino = {}
	tetromino.type = type
	tetromino.x = 6
	tetromino.y = 0

	if type == 'square' then
		tetromino.minos = {
			createMino(minoSprites[1], -1, -1),
		  createMino(minoSprites[1], 0, -1),
			createMino(minoSprites[1], -1, 0),
			createMino(minoSprites[1], 0, 0)
		}

  elseif type == 'j' then
		tetromino.minos = {
			createMino(minoSprites[2], 0, -1),
			createMino(minoSprites[2], 0, 0),
			createMino(minoSprites[2], 0, 1),
			createMino(minoSprites[2], -1, 1)
		}

	elseif type == 'l' then
		tetromino.minos = {
			createMino(minoSprites[3], 0, -1),
			createMino(minoSprites[3], 0, 0),
			createMino(minoSprites[3], 0, 1),
			createMino(minoSprites[3], 1, 1)
		}

	elseif type == 's' then
		tetromino.minos = {
			createMino(minoSprites[4], 1, 0),
			createMino(minoSprites[4], 0, 0),
			createMino(minoSprites[4], 0, 1),
			createMino(minoSprites[4], -1, 1)
		}

	elseif type == 't' then
		tetromino.minos = {
			createMino(minoSprites[5], -1, 0),
			createMino(minoSprites[5], 0, 0),
			createMino(minoSprites[5], 0, -1),
			createMino(minoSprites[5], 1, 0)
		}

	elseif type == 'z' then
		tetromino.minos = {
			createMino(minoSprites[6], -1, 0),
			createMino(minoSprites[6], 0, 0),
			createMino(minoSprites[6], 0, 1),
			createMino(minoSprites[6], 1, 1)
		}

	elseif type == 'long' then
		tetromino.minos = {
			createMino(minoSprites[7], -1, 0, 0),
			createMino(minoSprites[8], 0, 0, 0),
			createMino(minoSprites[8], 1, 0, 0),
			createMino(minoSprites[7], 2, 0, 180),
		}
	end

	return tetromino
end


function drawTetromino(tetromino)
	offsetX = 1 + (minoSize / 2) + (tetromino.x * minoSize) - minoSize
	offsetY = tetromino.y * minoSize + (minoSize / 2)

	for _, mino in pairs(tetromino.minos) do
		love.graphics.draw(minoSheet, mino.sprite, offsetX + mino.x * minoSize, offsetY + mino.y * minoSize,
			mino.rotate, 1, 1, minoSize/2, minoSize/2)
	end

end


function love.load()
	love.window.setMode(screen_width * scale_factor, screen_height * scale_factor)
	love.keyboard.setKeyRepeat(0)
	minoSheet = love.graphics.newImage('minos.png')
	minoSprites[1] = love.graphics.newQuad(0, 0, 8, 8, minoSheet:getDimensions())    -- square mino
	minoSprites[2] = love.graphics.newQuad(8, 0, 8, 8, minoSheet:getDimensions())    -- j mino
	minoSprites[3] = love.graphics.newQuad(16, 0, 8, 8, minoSheet:getDimensions())   -- l mino
	minoSprites[4] = love.graphics.newQuad(24, 0, 8, 8, minoSheet:getDimensions())   -- s mino
	minoSprites[5] = love.graphics.newQuad(0, 8, 8, 8, minoSheet:getDimensions())    -- t mino
	minoSprites[6] = love.graphics.newQuad(8, 8, 8, 8, minoSheet:getDimensions())    -- z mino
	minoSprites[7] = love.graphics.newQuad(16, 8, 8, 8, minoSheet:getDimensions())   -- long mino cap
	minoSprites[8] = love.graphics.newQuad(24, 8, 8, 8, minoSheet:getDimensions())   -- long mino body
  minoSprites[9] = love.graphics.newQuad(0, 16, 8, 8, minoSheet:getDimensions())   -- wall 1
	minoSprites[10] = love.graphics.newQuad(8, 16, 8, 8, minoSheet:getDimensions())  -- wall 2
	minoSprites[11] = love.graphics.newQuad(16, 16, 8, 8, minoSheet:getDimensions())  -- wall 3


  activeTetromino = createRandomTetromino()

end

function love.keypressed(key, isrepeat)
	isrepeat = isrepeat or false

	if key == 'escape' then
		love.event.quit()
	end

	if key == 'a' then
		activeTetromino.x = activeTetromino.x - 1

		for _, mino in pairs(activeTetromino.minos) do
			if (activeTetromino.x * minoSize) + (mino.x * minoSize) - (minoSize / 2) < (1 + minoSize) then
				print("hitting a wall on the left")
				activeTetromino.x = activeTetromino.x + 1
				break
			end
		end

	elseif key == 'd' then
		activeTetromino.x = activeTetromino.x + 1

		for _, mino in pairs(activeTetromino.minos) do
			if (activeTetromino.x * minoSize) + (mino.x * minoSize) + (minoSize / 2) > (1 + minoSize * 12) then
				print("hitting a wall on the right")
				activeTetromino.x = activeTetromino.x - 1
				break
			end
		end

	elseif key == 's' then
		activeTetromino.y = activeTetromino.y + 1
		if activeTetromino.y == 18 then
			activeTetromino.y = activeTetromino.y - 1
		end
		speed = refresh
	end
end


function love.update(dt)
	speed = speed - 1

	if speed <= 0 then
		activeTetromino.y = activeTetromino.y + 1
		if activeTetromino.y == 18 then
			activeTetromino.y = activeTetromino.y - 1
		end
		speed = refresh
	end
end

function love.draw()
	love.graphics.scale(scale_factor)
	love.graphics.setColor(255, 255, 255)
	love.graphics.setBackgroundColor(255, 255, 255)

	for i = 0, 5 do
		love.graphics.draw(minoSheet, minoSprites[11], 1, i * minoSize*3)
		love.graphics.draw(minoSheet, minoSprites[11], 89, i * minoSize*3)
		love.graphics.draw(minoSheet, minoSprites[10], 1, i * minoSize*3 + minoSize)
		love.graphics.draw(minoSheet, minoSprites[10], 89, i * minoSize*3 + minoSize)
		love.graphics.draw(minoSheet, minoSprites[9], 1, i * minoSize*3 + minoSize*2)
		love.graphics.draw(minoSheet, minoSprites[9], 89, i * minoSize*3 + minoSize*2)
	end

	drawTetromino(activeTetromino)

end
